package com.example.macstudent.kns_goparking;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class LauncherActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_launcher);

        final Context context;
        context = this;

        Thread timer = new Thread(){
            public void run(){
                try{
                    sleep(8000);
                }catch (Exception ex){
                    Log.e("Launcher","Thread wait failed");
                }
                finally {
                    Intent loginIntent = new Intent(context,LoginActivity.class);
                    startActivity(loginIntent);
                }
            }
        };

        timer.start();
    }
}
