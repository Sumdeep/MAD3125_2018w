package com.example.macstudent.kns_goparking;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class ReceiptActivity extends AppCompatActivity {

    @Override
    public void onBackPressed() {
        Intent mainIntent = new Intent(this, MainActivity.class);
        startActivity(mainIntent);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_receipt);

        SharedPreferences sp = getSharedPreferences("com.example.student.macstudent.kns_goparking.shared", Context.MODE_PRIVATE);
        String data = sp.getString("CarPlate","Data Missing");
        data += "\n" + sp.getString("Company", "Data Missing");
        data += "\n " + sp.getString("Payment", "Data Missing");
        data += "\n " + sp.getString("Lot", "Data Missing");
        data += "\n " + sp.getString("Spot", "Data Missing");
        data += "\n " + sp.getString("DateTime", "Data Missing");
        data += "\n" + String.valueOf(sp.getInt("Amount", 0));

        TextView txtInput = (TextView) findViewById(R.id.txtInput);
        txtInput.setText(data);

    }
}
