package com.example.macstudent.kns_goparking;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.Toast;

/**
 * Created by macstudent on 2018-04-16.
 */

public class ReportAdapter extends BaseAdapter
{
    LayoutInflater inflater;
    Context context;
    String[] companies = {"Lexus", "BMW"};
    String[] amounts = {"$10", "$30"};
    String[] lots = {"A", "B"};
    String[] spots = {"20", "1"};
    String[] datetimes  = {"12-12-2012 12:12:12 AM", "12-12-2012 12:12:12 AM"};
    String[] carPlates = {"ABCD123", "QWER456"} ;

    ReportAdapter(Context context){
        inflater = (LayoutInflater.from(context));
    }

    @Override
    public int getCount() {
        return companies.length;
    }

    @Override
    public Object getItem(int i) {
        return i;
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflater.inflate(R.layout.list_receipt_item,null);

        TextView company = (TextView) view.findViewById(R.id.txtCompany);
        TextView amount = (TextView) view.findViewById(R.id.txtAmount);
        TextView lot = (TextView) view.findViewById(R.id.txtLot);
        TextView spot = (TextView) view.findViewById(R.id.txtspot);
        TextView carPlate = (TextView) view.findViewById(R.id.txtCarPlate);
        TextView dateTime = (TextView) view.findViewById(R.id.txtDateTime);

        company.setText(companies[i]);
        amount.setText(amounts[i]);
        lot.setText(lots[i]);
        spot.setText(spots[i]);
        carPlate.setText(carPlates[i]);
        dateTime.setText(datetimes[i]);

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(context,"item clicked ", Toast.LENGTH_LONG).show();
            }
        });

        return view;
    }
}
